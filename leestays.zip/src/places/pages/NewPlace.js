import React from 'react';

const NewPlace = () => {
    return (
        <h2>New Place</h2>
    );
}

export default NewPlace;